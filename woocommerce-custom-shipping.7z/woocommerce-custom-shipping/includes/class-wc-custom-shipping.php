<?php

class WC_Custom_Shipping {

    public static function init() {
        add_action('woocommerce_product_options_general_product_data', [__CLASS__, 'add_custom_fields']);
        add_action('woocommerce_process_product_meta', [__CLASS__, 'save_custom_fields']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_scripts']);
        add_action('woocommerce_before_add_to_cart_button', [__CLASS__, 'display_shipping_dropdown']);
        add_action('woocommerce_add_to_cart', [__CLASS__, 'set_custom_shipping_session'], 10, 2);
        add_action('woocommerce_checkout_update_order_meta', [__CLASS__, 'update_order_meta']);
        add_filter('woocommerce_package_rates', [__CLASS__, 'custom_shipping_costs'], 10, 2);
        add_action('wp_ajax_update_shipping_zone', [__CLASS__, 'update_shipping_zone']);
        add_action('wp_ajax_nopriv_update_shipping_zone', [__CLASS__, 'update_shipping_zone']);
        add_action('admin_menu', [__CLASS__, 'add_plugin_admin_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
    }

    public static function add_plugin_admin_menu() {
        add_submenu_page(
            'woocommerce',
            'Custom Shipping Settings',
            'Custom Shipping',
            'manage_options',
            'custom-shipping-settings',
            [__CLASS__, 'display_plugin_settings_page']
        );
    }

    public static function display_plugin_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Custom Shipping Settings', 'woocommerce'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('custom_shipping_settings');
                do_settings_sections('custom_shipping_settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public static function register_settings() {
        $shipping_zones = WC_Shipping_Zones::get_zones();

        foreach ($shipping_zones as $zone) {
            $zone_name = sanitize_title($zone['zone_name']);

            register_setting('custom_shipping_settings', 'shipping_rate_' . $zone_name . '_green');
            register_setting('custom_shipping_settings', 'shipping_rate_' . $zone_name . '_red');
            register_setting('custom_shipping_settings', 'shipping_rate_' . $zone_name . '_black');

            add_settings_section(
                'shipping_rates_' . $zone_name,
                __('Shipping Rates for ' . $zone['zone_name'], 'woocommerce'),
                null,
                'custom_shipping_settings'
            );

            add_settings_field(
                'shipping_rate_' . $zone_name . '_green',
                __('Green Rate', 'woocommerce'),
                [__CLASS__, 'display_settings_field'],
                'custom_shipping_settings',
                'shipping_rates_' . $zone_name,
                [
                    'label_for' => 'shipping_rate_' . $zone_name . '_green',
                    'option_name' => 'shipping_rate_' . $zone_name . '_green',
                ]
            );

            add_settings_field(
                'shipping_rate_' . $zone_name . '_red',
                __('Red Rate', 'woocommerce'),
                [__CLASS__, 'display_settings_field'],
                'custom_shipping_settings',
                'shipping_rates_' . $zone_name,
                [
                    'label_for' => 'shipping_rate_' . $zone_name . '_red',
                    'option_name' => 'shipping_rate_' . $zone_name . '_red',
                ]
            );

            add_settings_field(
                'shipping_rate_' . $zone_name . '_black',
                __('Black Rate', 'woocommerce'),
                [__CLASS__, 'display_settings_field'],
                'custom_shipping_settings',
                'shipping_rates_' . $zone_name,
                [
                    'label_for' => 'shipping_rate_' . $zone_name . '_black',
                    'option_name' => 'shipping_rate_' . $zone_name . '_black',
                ]
            );
        }
    }

    public static function display_settings_field($args) {
        $option = get_option($args['option_name']);
        echo '<input type="number" id="' . esc_attr($args['label_for']) . '" name="' . esc_attr($args['option_name']) . '" value="' . esc_attr($option) . '" />';
    }

    public static function add_custom_fields() {
        echo '<div class="options_group">';
        woocommerce_wp_text_input([
            'id' => '_custom_product_color',
            'label' => __('Product Color', 'woocommerce'),
            'desc_tip' => 'true',
            'description' => __('Enter the product color.', 'woocommerce')
        ]);
        echo '</div>';
    }

    public static function save_custom_fields($post_id) {
        $custom_product_color = $_POST['_custom_product_color'];
        if (!empty($custom_product_color)) {
            update_post_meta($post_id, '_custom_product_color', esc_attr($custom_product_color));
        }
    }

    public static function enqueue_scripts() {
        wp_enqueue_script('custom-shipping-js', plugin_dir_url(__FILE__) . 'assets/js/custom-shipping.js', ['jquery'], '1.0', true);
        wp_localize_script('custom-shipping-js', 'wc_custom_shipping_params', [
            'ajax_url' => admin_url('admin-ajax.php')
        ]);
    }

    public static function display_shipping_dropdown() {
        $shipping_zones = WC_Shipping_Zones::get_zones();
        echo '<select id="shipping_zone" name="shipping_zone">';
        echo '<option value="">' . __('Select a shipping zone', 'woocommerce') . '</option>';
        foreach ($shipping_zones as $zone) {
            echo '<option value="' . esc_attr($zone['zone_name']) . '">' . esc_html($zone['zone_name']) . '</option>';
        }
        echo '</select>';
    }

    public static function set_custom_shipping_session($cart_item_key, $product_id) {
        if (isset($_POST['shipping_zone'])) {
            WC()->session->set('custom_shipping_zone', sanitize_text_field($_POST['shipping_zone']));
        }
    }

    public static function update_order_meta($order_id) {
        if ($shipping_zone = WC()->session->get('custom_shipping_zone')) {
            update_post_meta($order_id, '_custom_shipping_zone', $shipping_zone);
        }
    }

    public static function custom_shipping_costs($rates, $package) {
        if ($shipping_zone = WC()->session->get('custom_shipping_zone')) {
            foreach ($rates as $rate_key => $rate) {
                $shipping_class = $rate->get_shipping_class();
                $zone_rate_option = 'shipping_rate_' . sanitize_title($shipping_zone) . '_' . $shipping_class;
                $rate->cost = get_option($zone_rate_option, $rate->cost);
            }
        }
        return $rates;
    }

    public static function update_shipping_zone() {
        check_ajax_referer('update_shipping_zone_nonce', 'security');
        
        $shipping_zone = sanitize_text_field($_POST['shipping_zone']);
        $new_price = 100; // Example base price

        // Calculate the new price based on the selected shipping zone and product color
        switch ($shipping_zone) {
            case 'India':
                $new_price += get_option('shipping_rate_india_green', 5);
                break;
            case 'USA':
                $new_price += get_option('shipping_rate_usa_green', 8);
                break;
            case 'UK':
                $new_price += get_option('shipping_rate_uk_green', 11);
                break;
        }

        wp_send_json_success(['new_price' => wc_price($new_price)]);
    }
}

WC_Custom_Shipping::init();
?>
