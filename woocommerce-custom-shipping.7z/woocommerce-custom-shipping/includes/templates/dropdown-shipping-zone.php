<?php
$shipping_zones = WC_Shipping_Zones::get_zones();
?>
<select id="shipping_zone" name="shipping_zone">
    <option value=""><?php _e('Select a shipping zone', 'woocommerce'); ?></option>
    <?php foreach ($shipping_zones as $zone): ?>
        <option value="<?php echo esc_attr($zone['zone_name']); ?>"><?php echo esc_html($zone['zone_name']); ?></option>
    <?php endforeach; ?>
</select>
