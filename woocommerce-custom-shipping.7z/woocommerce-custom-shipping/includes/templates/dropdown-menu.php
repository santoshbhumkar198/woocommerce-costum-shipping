<?php
// Query to fetch menu items dynamically
$menu_items = wp_get_nav_menu_items('your-menu-slug');

if ($menu_items) {
    echo '<select id="custom_menu_dropdown" name="custom_menu_dropdown">';
    foreach ($menu_items as $menu_item) {
        echo '<option value="' . esc_attr($menu_item->ID) . '">' . esc_html($menu_item->title) . '</option>';
    }
    echo '</select>';
} else {
    echo '<p>No menu items found.</p>';
}
?>
