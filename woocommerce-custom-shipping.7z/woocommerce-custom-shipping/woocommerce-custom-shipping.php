<?php
/*
Plugin Name: WooCommerce Custom Shipping
Description: Custom WooCommerce plugin for variable products with dynamic shipping zones and pricing.
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Include the main plugin class file
require_once plugin_dir_path(__FILE__) . 'includes/class-wc-custom-shipping.php';

// Initialize the plugin
add_action('plugins_loaded', ['WC_Custom_Shipping', 'init']);
?>
