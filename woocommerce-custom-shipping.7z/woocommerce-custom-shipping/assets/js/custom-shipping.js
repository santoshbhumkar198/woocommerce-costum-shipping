jQuery(document).ready(function ($) {
  $("#shipping_zone").change(function () {
    var shipping_zone = $(this).val();
    console.log("Selected shipping zone:", shipping_zone);

    $.ajax({
      type: "POST",
      url: wc_custom_shipping_params.ajax_url,
      data: {
        action: "update_shipping_zone",
        shipping_zone: shipping_zone,
      },
      success: function (response) {
        if (response.success) {
          var new_price = response.data.new_price;
          console.log("New price:", new_price);
          $(".product .price").html(new_price);
        } else {
          console.log("Error updating shipping zone.");
        }
      },
      error: function (error) {
        console.log("Error updating shipping zone:", error);
      },
    });
  });
});
